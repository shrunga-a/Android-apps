package com.atul.musicplayer.listener;

import android.content.Context;

import com.atul.musicplayer.model.Music;

public interface PlayListListener {
    void option(Context context, Music music);
}
