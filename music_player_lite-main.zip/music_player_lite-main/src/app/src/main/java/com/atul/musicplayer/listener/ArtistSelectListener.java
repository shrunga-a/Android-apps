package com.atul.musicplayer.listener;

import com.atul.musicplayer.model.Artist;

public interface ArtistSelectListener {
    void selectedArtist(Artist artist);
}
